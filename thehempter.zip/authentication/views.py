from django.contrib.auth import authenticate, login, logout
from django.core.mail import send_mail
from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.contrib.auth.models import User
from django.contrib import messages

from thehempter import settings


# Create your views here.
def home(request):
    user_query1 = User.objects.all()
    print(user_query1)
    return render(request, 'authentication/index.html')

def signup(request):

    if request.method == "POST":
        username = request.POST.get('username')
        fname = request.POST.get('fname')
        lname = request.POST.get('lname')
        email = request.POST.get('email')
        password = request.POST.get('password1')
        password_confirm = request.POST.get('password2')

        user_query1 = User.objects.all()
        print(user_query1)

        if User.objects.filter(username = username):
            print('1')
            messages.error(request, 'Username existiert leider bereits!')
            return redirect('home')

        if User.objects.filter(email = email):
            print('2')
            messages.error(request, 'Die angegebene E-Mail existiert bereits!')
            return redirect('home')

        if len(username)>10:
            print('3')
            messages.error(request, 'Benutzer muss unter 10 Zeichen haben')
            return redirect('home')

        if password != password_confirm:
            print('4')
            messages.error(request, 'Die Passwörter stimmen nicht überein!')
            return redirect('home')


        user_query = User.objects.create_user(username, email, password)


        user_query.first_name = fname
        user_query.last_name = lname

        user_query.save()

        messages.success(request, 'Dein Account wurde erfolgreich erstellt. Wir haben ihnen einen Bestätigunsmail geschickt. Bitte überprüfen sie diese und bestätigen sie damit Ihre Identität')

        # Login E-Mail

        # import smtplib
        # from email.message import EmailMessage
        #
        # msg = EmailMessage()
        # msg.set_content("dies ist ein Test")
        # #msg.set_content('Hello ' + user_query.first_name + '!! \n' + 'Willkommen auf der Website von TheHempter!! \n Habt viel Spaß auf unserer Website \n Wir haben Ihnen eine Bestätigungsmail geschickt. Bitte bestätigen sie Ihre E-Mail Adresse! \n\n Mit freundlichen Grüßen \n TheHempter')
        #
        # msg['subject'] = 'automatische Email'
        # msg['From'] = 'businesshempter@gmail.com'
        # msg['To'] = 'businesshempter@gmail.com'
        #
        # server = smtplib.SMTP_SSL('smtp.gmail.com',587)
        # server.login('businesshempter@gmail.com', 'pgdyhfccafoqarqm')
        # server.send_message(msg)
        # server.quit()

        subject = 'Test E-Mail'
        message = 'Dies ist eine Test-E-Mail von Django.'
        from_email = 'businesshempter@gmail.com'
        recipient_list = ['nils.philipp1@gmx.de']
        try:
            send_mail(subject, message, from_email, recipient_list)
            print("E-Mail erfolgreich gesendet!")

        except Exception as e: \
            print(f"E-Mail konnte nicht gesendet werden: {e}")

        return redirect('signin')

    return render(request, 'authentication/signup.html')

def signin(request):

    if request.method == ('POST'):
        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(username=username, password=password)

        if user is not None:
            login(request, user)
            fname = user.first_name
            return render(request, 'authentication/index.html', {'fname': fname})
        else:
            messages.error(request, 'Das Passwort oder der Username sind entweder falsch oder passen nicht zueinander!')
            return redirect('home')

    return render(request, 'authentication/signin.html')

def signout(request):
    logout(request)
    messages.success(request, 'Sie haben sich erfolgreich abgemeldet')
    return redirect('home')